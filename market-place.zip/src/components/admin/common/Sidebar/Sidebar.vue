<script >
import IconAdminForms from '@/components/icons/IconAdminForms.vue'
import IconAdminCategory from '@/components/icons/IconAdminCategory.vue'
export default {
  components: {
    IconAdminForms,
    IconAdminCategory
  },
  data() {
    return {
      routers: [
        {
          router_name: "Поля и формы",
          router_link: "/admin/forms",
          router_icon: "IconAdminForms"
        },
        {
          router_name: "Категории",
          router_link: "/admin",
          router_icon: "IconAdminCategory"
        }
      ]
    };
  },
}
</script>

<template>
  <div class="sidebar">
    <h2 class="sidebar-header">Админ панель:</h2>
    <div class="sidebar-nav">
      <router-link v-for="router of routers" :to="router.router_link" class="link">
        <component :is="router.router_icon" class="icon" />
        <span class="router-name">
          {{ router.router_name }}
        </span>
      </router-link>
    </div>
    <div class="sidebar-footer">

    </div>
  </div>
</template>


<style scoped>
  @import 'Sidebar.sass';
</style>