<template>
  <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3.98741 12C3.16708 11.0182 2.71759 9.77943 2.71741 8.5C2.71741 5.48 5.18741 3 8.21741 3H13.2174C16.2374 3 18.7174 5.48 18.7174 8.5C18.7174 11.52 16.2474 14 13.2174 14H10.7174" stroke="#333333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M21.4474 12C22.2677 12.9818 22.7172 14.2206 22.7174 15.5C22.7174 18.52 20.2474 21 17.2174 21H12.2174C9.19741 21 6.71741 18.52 6.71741 15.5C6.71741 12.48 9.18741 10 12.2174 10H14.7174" stroke="#333333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</template>
