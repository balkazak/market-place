<template>
  <div class="page-content">
    <div class="mb-4">

      Торговая площадка

      /
      Категории
    </div>
<!--    <div class="list-header">-->
<!--      <span>Категория</span>-->
<!--      <div>-->
<!--        <IconPlus />-->
<!--        Добавить-->
<!--      </div>-->
<!--    </div>-->
<!--    <ul>-->
<!--      <li v-for="(item, index) in items" :key="index">-->
<!--        <IconApple />-->

<!--        {{ item }}-->
<!--        <button @click="editItem(index)">Edit</button>-->
<!--        <button @click="deleteItem(index)">Delete</button>-->
<!--      </li>-->
<!--    </ul>-->
    <div class="d-flex ">
      <table class="table">
        <thead class="thead-dark">
        <tr class="table-head">
          <th colspan="2" scope="col">Категория</th>
          <th colspan="3" scope="col" @click="addItem"><IconPlus /> Добавить</th>
        </tr>
        </thead>
        <draggable v-model="categories" tag="tbody" item-key="name">
          <template #item="{ element, index }">
            <tr :class="{ 'active': element.active }" @click="setItem(element, index, 'category')">
              <td><IconDrag /></td>

              <td scope="row"><IconApple /></td>
              <td class="w-200">{{ element.name }}</td>
              <td class="text-center" @click="editItem(index, 'category')"><IconEdit /></td>
              <td class="text-center" @click="deleteItem(index, 'category')"><IconDelete /></td>

            </tr>
          </template>
        </draggable>
      </table>
      <table v-if="selectedCategory" class="table">
        <thead class="thead-dark">
        <tr class="table-head">
          <th colspan="2  " scope="col">Категория</th>
          <th colspan="2" scope="col" @click="addItem"><IconPlus /> Добавить</th>
        </tr>
        </thead>
        <draggable v-model="subCategories " tag="tbody" item-key="name">
          <template #item="{ element, index }">
            <tr :class="{ 'active': element.active }" @click="setItem(element, index, 'subcategory')">
              <td><IconDrag /></td>

              <td class="w-200">{{ element.name }}</td>
              <td class="text-center" @click="editItem(index, 'subcategory')"><IconEdit /></td>
              <td class="text-center" @click="deleteItem(index, 'subcategory')"><IconDelete /></td>

            </tr>
          </template>
        </draggable>
      </table>
      <table v-if="selectedSubCategory" class="table">
        <thead class="thead-dark">
        <tr class="table-head">
          <th colspan="2  " scope="col">Категория</th>
          <th colspan="2" scope="col" @click="addItem"><IconPlus /> Добавить</th>
        </tr>
        </thead>
        <draggable v-model="subSubCategories " tag="tbody" item-key="name">
          <template #item="{ element, index }">
            <tr :class="{ 'active': element.active }" @click="setItem(element, index, 'subsubcategory')">
              <td><IconDrag /></td>

              <td class="w-200">{{ element.name }}</td>
              <td class="text-center" @click="editItem(index, 'subsubcategory')"><IconEdit /></td>
              <td class="text-center" @click="deleteItem(index, 'subsubcategory')"><IconDelete /></td>

            </tr>
          </template>
        </draggable>
      </table>
      <table v-if="selectedSubSubCategory" class="table">
        <thead class="thead-dark">
        <tr class="table-head">
          <th colspan="2  " scope="col">Категория</th>
          <th colspan="3" scope="col" @click="addItem"><IconPlus /> Добавить</th>
        </tr>
        </thead>
        <draggable v-model="lastCategories " tag="tbody" item-key="name">
          <template #item="{ element, index }">
            <tr :class="{ 'active': element.active }" @click="setItem(element, index, 'lastcategory')">
              <td><IconDrag /></td>

              <td class="w-200">{{ element.name }}</td>
              <td class="text-center"><IconLink /></td>

              <td class="text-center" @click="editItem(index, 'lastcategory')"><IconEdit /></td>
              <td class="text-center" @click="deleteItem(index, 'lastcategory')"><IconDelete /></td>

            </tr>
          </template>
        </draggable>
      </table>
    </div>

<!--    <input v-model="newItem" @keyup.enter="addItem" placeholder="Add a new item">-->
  </div>
</template>

<script>
import IconPlus from "@/components/icons/IconPlus.vue";
import IconApple from "@/components/icons/IconApple.vue";
import IconDrag from "@/components/icons/IconDrag.vue";
import IconEdit from "@/components/icons/IconEdit.vue";
import IconDelete from "@/components/icons/IconDelete.vue";
import IconLink from "@/components/icons/IconLink.vue";
import draggable from "vuedraggable";
export default {

  components: {IconDelete, IconEdit, IconDrag, IconApple, IconPlus, IconLink, draggable},
  data() {
    return {
      items: ['Телефоны', 'Item 2', 'Item 3'],
      newItem: '',
      categories: [
        { name: "Abby", active: false },
        { name: "Brooke", active: false },
        { name: "Courtenay", active: false },
        { name: "David", active: false }
      ],
      subCategories: [
        { name: "Abby", active: false },
        { name: "Brooke", active: false },
        { name: "Courtenay", active: false },
        { name: "David", active: false }
      ],
      subSubCategories: [
        { name: "Abby", active: false },
        { name: "Brooke", active: false },
        { name: "Courtenay", active: false },
        { name: "David", active: false }
      ],
      lastCategories: [
        { name: "Abby", active: false },
        { name: "Brooke", active: false },
        { name: "Courtenay", active: false },
        { name: "David", active: false }
      ],
      dragging: false,
      selectedCategory: null,
      selectedSubCategory: null,
      selectedSubSubCategory: null,
      selectedLastCategory: null,
      isActive: false
    };
  },
  methods: {
    setItem(el, index, type) {
      switch (type) {
        case 'category':

          const updatedCategory = this.categories.map(obj => {
            if (obj.hasOwnProperty('active')) {
              obj['active'] = false;
            }
            return obj;
          });

          this.categories = updatedCategory

          this.selectedCategory = el;
          this.categories[index].active = true
          break;
        case 'subcategory':
          const updatedSubCategory = this.subCategories.map(obj => {
            if (obj.hasOwnProperty('active')) {
              obj['active'] = false;
            }
            return obj;
          });

          this.subCategories = updatedSubCategory

          this.selectedSubCategory = el;
          this.subCategories[index].active = true
          break;
        case 'subsubcategory':
          const updatedSubSubCategory = this.subSubCategories.map(obj => {
            if (obj.hasOwnProperty('active')) {
              obj['active'] = false;
            }
            return obj;
          });

          this.subSubCategories = updatedSubSubCategory

          this.selectedSubSubCategory = el;
          this.subSubCategories[index].active = true
          break;
        case 'lastcategory':
          const updatedLastCategory = this.lastCategories.map(obj => {
            if (obj.hasOwnProperty('active')) {
              obj['active'] = false;
            }
            return obj;
          });

          this.lastCategories = updatedLastCategory

          this.selectedLastCategory = el;
          this.lastCategories[index].active = true
          break;
        default:
          console.log('Invalid day');
      }

    },
    addItem() {
      const newItem = {}
      newItem.name = prompt('add item:');
      if (newItem.name) this.categories.push(newItem);

    },
    editItem(index, type) {
      switch (type) {
        case 'category':
          let categoryItem = prompt('Edit item:', this.categories[index].name);
          if (categoryItem !== null) {
            this.categories[index].name = categoryItem;
          }
          break;
        case 'subcategory':
          let subCategoryItem = prompt('Edit item:', this.subCategories[index].name);
          if (subCategoryItem !== null) {
            this.subCategories[index].name = subCategoryItem;
          }
          break;
        case 'subsubcategory':
          let subSubCategoryItem = prompt('Edit item:', this.subSubCategories[index].name);
          if (subSubCategoryItem !== null) {
            this.subSubCategories[index].name = subSubCategoryItem;
          }
          break;
        case 'lastcategory':
          let lastCategoryItem = prompt('Edit item:', this.lastCategories[index].name);
          if (lastCategoryItem !== null) {
            this.lastCategories[index].name = lastCategoryItem;
          }
          break;
        default:
          console.log('Invalid day');
      }


    },
    deleteItem(index, type) {
      const confirmDelete = confirm('Are you sure you want to delete this item?');
      if (confirmDelete) {
        switch (type) {
          case 'category':
            this.categories.splice(index, 1);
            break;
          case 'subcategory':
            this.subCategories.splice(index, 1);
            break;
          case 'subsubcategory':
            this.subSubCategories.splice(index, 1);
            break;
          case 'lastcategory':
            this.lastCategories.splice(index, 1);
            break;
          default:
            console.log('Invalid day');
        }

      }
    },
  },
};
</script>

<style scoped>
@import './CategorList.sass';
</style>
