<script setup>
import { RouterView } from 'vue-router'
import Header from "@/components/common/Header/Header.vue";
import AdminHeader from "@/components/admin/common/Header/Header.vue";
import AdminSideBar from "@/components/admin/common/Sidebar/Sidebar.vue";
import Footer from "@/components/common/Footer/Footer.vue";
</script>

<template>
  <AdminHeader v-if="$route.path === '/admin'"/>
  <Header v-else/>
  <div class="d-flex content">
    <AdminSideBar />
    <RouterView />
  </div>
  <Footer />
</template>

<style scoped>

</style>
